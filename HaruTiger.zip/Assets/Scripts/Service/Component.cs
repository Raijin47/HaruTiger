using System;

[Serializable]
public abstract class Component
{
    public abstract void Init();
}